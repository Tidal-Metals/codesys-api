"""Process/state helpers for managed Modbus RTU simulator instances."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from typing import Any

from modbus_rtu_slave_sim import normalize_device


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SIMULATOR_STATE_PATH = os.path.join(SCRIPT_DIR, "modbus_simulator_state.json")


def read_state() -> dict[str, Any]:
    if not os.path.exists(SIMULATOR_STATE_PATH):
        return {"simulators": {}}
    try:
        with open(SIMULATOR_STATE_PATH, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if isinstance(data, dict) and isinstance(data.get("simulators"), dict):
            return data
    except Exception:
        pass
    return {"simulators": {}}


def write_state(state: dict[str, Any]) -> None:
    with open(SIMULATOR_STATE_PATH, "w", encoding="utf-8") as handle:
        json.dump(state, handle, indent=2, sort_keys=True)


def pid_running(pid: int | None) -> bool:
    if not pid:
        return False

    try:
        pid_value = int(pid)
    except Exception:
        return False

    if os.name == "nt":
        try:
            result = subprocess.run(
                ["tasklist", "/FI", "PID eq {0}".format(pid_value)],
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            output = result.stdout or ""
            return str(pid_value) in output and "No tasks are running" not in output
        except Exception:
            return False

    try:
        os.kill(pid_value, 0)
        return True
    except Exception:
        return False


def stop_pid(pid: int | None) -> None:
    if not pid:
        return
    try:
        subprocess.run(
            ["taskkill", "/PID", str(int(pid)), "/T", "/F"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass


def windows_creationflags() -> int:
    flags = 0
    if os.name == "nt":
        flags |= getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        flags |= getattr(subprocess, "DETACHED_PROCESS", 0)
        flags |= getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return flags


def get_simulator_status() -> dict[str, Any]:
    state = read_state()
    simulators = []
    for port, entry in sorted(state.get("simulators", {}).items()):
        row = dict(entry)
        row["port"] = port
        row["running"] = pid_running(entry.get("pid"))
        simulators.append(row)
    return {"success": True, "simulators": simulators}


def normalize_manifest_devices(devices: list[dict[str, Any]]) -> list[dict[str, Any]]:
    normalized_devices: list[dict[str, Any]] = []
    for entry in devices:
        normalized = normalize_device(entry)
        normalized_devices.append(
            {
                "unit": normalized["unit"],
                "name": normalized["name"],
                "coilsMap": normalized["coilsMap"],
                "discreteInputsMap": normalized["discreteInputsMap"],
                "holdingMap": normalized["holdingMap"],
                "inputRegistersMap": normalized["inputRegistersMap"],
            }
        )
    return normalized_devices


def apply_simulator(buses: list[dict[str, Any]]) -> dict[str, Any]:
    state = read_state()
    simulators = dict(state.get("simulators", {}))
    results = []

    for bus in buses:
        if not isinstance(bus, dict):
            return {"success": False, "error": "Each bus entry must be an object"}

        port = str(bus.get("pcPort", bus.get("port", ""))).strip()
        if not port:
            return {"success": False, "error": "Each bus entry must define pcPort or port"}

        devices = bus.get("devices")
        if not isinstance(devices, list) or not devices:
            return {"success": False, "error": f"Bus {port} must contain a non-empty devices list"}

        baudrate = int(bus.get("baudrate", 9600))
        multidrop = bus.get("multidrop", False)
        if not isinstance(multidrop, bool):
            return {"success": False, "error": "multidrop must be a boolean"}
        if multidrop and baudrate > 38400:
            return {"success": False, "error": "multidrop requires baudrate <= 38400"}
        bytesize = int(bus.get("bytesize", 8))
        parity = str(bus.get("parity", "N"))
        stopbits = int(bus.get("stopbits", 1))
        timeout = float(bus.get("timeout", 1.0))

        normalized_devices = normalize_manifest_devices(devices)
        manifest = {"devices": normalized_devices}
        manifest_path = os.path.join(SCRIPT_DIR, "templates", f"modbus_simulator_{port}.json")
        stdout_path = os.path.join(SCRIPT_DIR, f"modbus_sim_{port}_managed_stdout.log")
        stderr_path = os.path.join(SCRIPT_DIR, f"modbus_sim_{port}_managed_stderr.log")

        os.makedirs(os.path.dirname(manifest_path), exist_ok=True)
        with open(manifest_path, "w", encoding="utf-8") as handle:
            json.dump(manifest, handle, indent=2, sort_keys=True)

        prior = simulators.get(port, {})
        prior_pid = prior.get("pid")
        if prior_pid and pid_running(prior_pid):
            stop_pid(prior_pid)
            time.sleep(0.5)

        stdout_handle = open(stdout_path, "w", encoding="utf-8")
        stderr_handle = open(stderr_path, "w", encoding="utf-8")
        command = [
            sys.executable,
            os.path.join(SCRIPT_DIR, "modbus_rtu_slave_sim.py"),
            "--port", port,
            "--manifest", manifest_path,
            "--baudrate", str(baudrate),
            "--bytesize", str(bytesize),
            "--parity", parity,
            "--stopbits", str(stopbits),
            "--timeout", str(timeout),
        ]
        if multidrop:
            command.append("--multidrop")
        process = subprocess.Popen(
            command,
            cwd=SCRIPT_DIR,
            stdout=stdout_handle,
            stderr=stderr_handle,
            creationflags=windows_creationflags(),
            close_fds=True,
        )
        time.sleep(1.0)

        entry = {
            "pid": process.pid,
            "manifestPath": manifest_path,
            "stdout": stdout_path,
            "stderr": stderr_path,
            "baudrate": baudrate,
            "multidrop": multidrop,
            "bytesize": bytesize,
            "parity": parity,
            "stopbits": stopbits,
            "timeout": timeout,
            "deviceCount": len(normalized_devices),
            "devices": normalized_devices,
        }
        simulators[port] = entry
        results.append({
            "port": port,
            **entry,
            "running": pid_running(process.pid),
        })

    write_state({"simulators": simulators})
    return {
        "success": all(item.get("running") for item in results),
        "simulators": results,
    }
